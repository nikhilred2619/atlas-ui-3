Validation output for commit 12f63c4bd84666377b6804e73b973cfb88abdb1c.
Local repository and temporary worktree paths have been replaced with /LOCAL_REPO and /VALIDATION_WORKTREE respectively for privacy. No test output lines or warning messages were removed.
